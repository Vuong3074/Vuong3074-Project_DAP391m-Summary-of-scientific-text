import os
from pdf_to_markdown import pdf_to_markdown
from summarizer import summarize_markdown_sections
from speak_text import speak_from_file

def main(pdf_path):
    print(f" Reading and converting PDF to Markdown from: {pdf_path}")
    md_text = pdf_to_markdown(pdf_path)

    print(" Summarizing each section...")
    summary = summarize_markdown_sections(md_text)

   # Create file names based on original name
    base_name = os.path.splitext(os.path.basename(pdf_path))[0]
    summary_path = os.path.join(os.path.dirname(pdf_path), f"{base_name}_summary.txt")
    audio_path = os.path.join(os.path.dirname(pdf_path), f"{base_name}_summary.mp3")

    # Write the summary to a text file
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write(summary)
    print(f" Summary saved to file: {summary_path}")

    # Generate and save the audio
    print(" Generating speech audio file...")
    speak_from_file(summary_path, language="en", save_path=audio_path)
    print(f"Speech audio created at:{audio_path}")

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python main.py <duong_dan_pdf>")
    else:
        main(sys.argv[1])
