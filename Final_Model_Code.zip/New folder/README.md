# 📄 PDF Scientific Paper Summarizer with BART

Dự án này cho phép bạn tóm tắt các bài báo khoa học (định dạng PDF) thành văn bản ngắn gọn, rõ ràng, theo từng phần nội dung. Mô hình sử dụng là `facebook/bart-large-cnn` từ HuggingFace.

## ✅ Tính năng

- 🧩 Chuyển file PDF sang định dạng Markdown
- 🔍 Tách và tóm tắt nội dung theo từng phần: Abstract, Introduction, Method, Results, Conclusion,...
- 🧠 Sử dụng mô hình BART để tóm tắt từng phần
- 📄 Xuất ra file `.txt` chứa toàn bộ bản tóm tắt
- 🔊 Tự động đọc tóm tắt bằng giọng nói (gTTS + pygame)

## 📦 Yêu cầu cài đặt

Chạy lệnh sau để cài các thư viện cần thiết:

```bash
pip install torch transformers PyMuPDF gtts pygame