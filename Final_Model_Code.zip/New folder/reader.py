import fitz 
import re

SECTION_KEYWORDS = {
    "abstract": "Abstract",
    "introduction": "Introduction",
    "related work": "Related Work",
    "background": "Background",
    "method": "Method",
    "methodology": "Method",
    "approach": "Method",
    "experiment": "Results",
    "evaluation": "Results",
    "results": "Results",
    "discussion": "Discussion",
    "conclusion": "Conclusion",
    "future work": "Conclusion"
}

def normalize_text(text):
    return re.sub(r'\W+', '', text).lower()

def extract_sections(file_path):
    doc = fitz.open(file_path)
    sections = []
    current_section = {
        "section_title": "Front Matter",
        "section_group": "Front Matter",
        "text": ""
    }

    for page in doc:
        lines = page.get_text().split('\n')
        for line in lines:
            norm_line = normalize_text(line)
            matched = False
            for raw, group in SECTION_KEYWORDS.items():
                if norm_line.startswith(normalize_text(raw)):
                    if current_section["text"].strip():
                        sections.append(current_section)
                    current_section = {
                        "section_title": line.strip(),
                        "section_group": group,
                        "text": ""
                    }
                    matched = True
                    break
            if not matched:
                current_section["text"] += line + "\n"

    if current_section["text"].strip():
        sections.append(current_section)

    return sections
