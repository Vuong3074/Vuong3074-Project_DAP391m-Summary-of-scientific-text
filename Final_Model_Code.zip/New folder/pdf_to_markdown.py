import fitz
import re

SECTION_PATTERNS = [
    r'^abstract\b',
    r'^introduction\b',
    r'^related work\b',
    r'^background\b',
    r'^method(?:s|ology)?\b',
    r'^experiment(?:s)?\b',
    r'^results?\b',
    r'^discussion\b',
    r'^conclusion\b',
    r'^future work\b',
    r'^references\b'
]

def is_heading(line):
    normalized = line.lower().strip()
    for pattern in SECTION_PATTERNS:
        if re.match(pattern, normalized):
            return True
    return False

def pdf_to_markdown(pdf_path):
    doc = fitz.open(pdf_path)
    lines = []

    for page in doc:
        for line in page.get_text("text").split("\n"):
            if is_heading(line):
                lines.append(f"## {line.strip()}")
            else:
                lines.append(line.strip())

    return "\n".join(lines)
