from transformers import pipeline
import re

# Initialize the summarization pipeline
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

def split_into_sections(md_text):
    """Split markdown text into sections based on markdown headers (##)."""
    pattern = r"^##\s+(.*)$"
    lines = md_text.splitlines()
    sections = []
    current_title = "Front Matter"
    current_content = []

    for line in lines:
        heading_match = re.match(pattern, line.strip())
        if heading_match:
            if current_content:
                sections.append({
                    "title": current_title,
                    "content": "\n".join(current_content).strip()
                })
            current_title = heading_match.group(1).strip()
            current_content = []
        else:
            current_content.append(line)

    if current_content:
        sections.append({
            "title": current_title,
            "content": "\n".join(current_content).strip()
        })

    return sections

def split_text(text, max_words=500):
    """Split long text into smaller chunks to avoid exceeding model input limits."""
    words = text.split()
    return [" ".join(words[i:i + max_words]) for i in range(0, len(words), max_words)]

def summarize_section(section_text, max_length=180, min_length=50):
    """Summarize a section; chunk if needed to avoid index out-of-range errors."""
    try:
        if len(section_text.split()) < min_length:
            return section_text.strip()  # Skip summarizing very short text

        chunks = split_text(section_text)
        summaries = []

        for chunk in chunks:
            if len(chunk.split()) < min_length:
                summaries.append(chunk)
                continue
            result = summarizer(chunk, max_length=max_length, min_length=min_length, do_sample=False)
            summaries.append(result[0]['summary_text'])

        return "\n".join(summaries)
    except Exception as e:
        return f"[Summarization error: {str(e)}]"

def summarize_markdown_sections(md_text):
    """Summarize all markdown content section by section."""
    sections = split_into_sections(md_text)
    summarized = []

    for sec in sections:
        # Skip irrelevant sections
        title_lower = sec["title"].lower()
        if any(skip in title_lower for skip in ["references", "figures", "tables"]):
            continue

        summary = summarize_section(sec['content'])
        summarized.append(f"## {sec['title']}\n\n{summary}\n")

    return "\n".join(summarized)
