from gtts import gTTS
import pygame
import os
import tempfile

def speak_text(text, language='en', slow=False, save_path=None):
    """
    Convert text to speech and either play it or save it as an MP3 file.
    """
    try:
        tts = gTTS(text=text, lang=language, slow=slow)

        if save_path:
            # Save the audio directly to the specified file
            tts.save(save_path)
            print(f" Voice saved to: {save_path}")
        else:
            # Create a temporary file to play audio through the speaker
            with tempfile.NamedTemporaryFile(delete=False, suffix='.mp3') as temp_file:
                temp_filename = temp_file.name
                tts.save(temp_filename)

            pygame.mixer.init()
            pygame.mixer.music.load(temp_filename)
            pygame.mixer.music.play()

            while pygame.mixer.music.get_busy():
                pygame.time.Clock().tick(10)

            pygame.mixer.quit()
            os.remove(temp_filename)
            print(" Finished reading the text.")
    except Exception as e:
        print(f" Error while reading the text: {e}")

def speak_from_file(file_path, language='en', slow=False, save_path=None):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            text = f.read()
        speak_text(text, language=language, slow=slow, save_path=save_path)
    except Exception as e:
        print(f" Error while reading file: {e}")
